#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 17:48:19 2020

@author: ginger
@email:  gingerxjiang@gmail.com
"""

from ..utils.functions  import *

def hello_gendata():
    hello_utils()
    print("Hello, gendata.hello_gendata!")
    return
