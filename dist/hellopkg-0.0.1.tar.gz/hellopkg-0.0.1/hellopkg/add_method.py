#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 15:58:19 2020

@author: ginger
@email:  gingerxjiang@gmail.com
"""


class AddTwo():
    def __init__(self):
        pass

    def add_data(self, x, y):
        return (x+y)


class AddThree():
    def __init__(self):
        pass

    def add_data(self, x, y, z):
        return (x+y+z)


def funAdd():
    print("funAdd in module_11.")
    return


