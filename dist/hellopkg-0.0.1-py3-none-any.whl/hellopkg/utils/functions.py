#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 18:05:21 2020

@author: ginger
@email:  gingerxjiang@gmail.com
"""


def hello_utils():
    print("Hello, I am utils.hello_utils function!")
    return
